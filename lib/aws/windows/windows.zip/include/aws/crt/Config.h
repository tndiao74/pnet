#pragma once
/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#define AWS_CRT_CPP_VERSION "0.36.0"
#define AWS_CRT_CPP_VERSION_MAJOR 0
#define AWS_CRT_CPP_VERSION_MINOR 36
#define AWS_CRT_CPP_VERSION_PATCH 0
#define AWS_CRT_CPP_GIT_HASH ""
